<?php

// wallet doge FaucetPay

// link ->  https://maniabiz.space/?r=DR3Z9PYM4GgbCtxmyGSQ4WPGfAGRrYqkam

$doge = "Paste Disini";
$cookie = "Paste Disini";
